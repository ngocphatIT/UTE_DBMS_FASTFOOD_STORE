﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DALClasses
{
    public class ThamGiaLamViecDAL
    {
        QUANLYCUAHANGEntities db = new QUANLYCUAHANGEntities();

        //public List<> getList()
        //{
        //    var list = db..ToList();
        //    return list;
        //}
    }
}
