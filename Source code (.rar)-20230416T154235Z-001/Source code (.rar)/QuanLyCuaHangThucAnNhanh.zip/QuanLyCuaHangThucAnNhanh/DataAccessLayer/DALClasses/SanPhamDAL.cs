﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DataAccessLayer.DALClasses
{
    public class SanPhamDAL
    {
        QUANLYCUAHANGEntities db = new QUANLYCUAHANGEntities();

        public List<SanPham> getSanPhamList()
        {
            var list = db.SanPhams.ToList();
            return list;
        }

        public SanPham findByName(string name)
        {
            return db.SanPhams.Where(n => n.TenSP == name).FirstOrDefault();
        }

        public SanPham findById(string id)
        {
            return db.SanPhams.Where(n => n.MaSP == id).FirstOrDefault();

        }
    }
}
