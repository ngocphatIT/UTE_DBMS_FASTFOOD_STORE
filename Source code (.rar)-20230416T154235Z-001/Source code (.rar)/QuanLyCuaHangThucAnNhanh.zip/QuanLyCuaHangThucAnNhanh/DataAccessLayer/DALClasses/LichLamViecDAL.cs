﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DALClasses
{
    public class LichLamViecDAL
    {
        QUANLYCUAHANGEntities db = new QUANLYCUAHANGEntities();

        public List<LichLamViec> getLichLamViecList()
        {
            var list = db.LichLamViecs.ToList();
            return list;
        }
    }
}
