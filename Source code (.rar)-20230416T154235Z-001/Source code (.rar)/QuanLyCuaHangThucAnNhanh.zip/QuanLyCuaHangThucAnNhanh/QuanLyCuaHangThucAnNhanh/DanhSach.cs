﻿using BussinessLogicLayer.LogicClasses;
using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyCuaHangThucAnNhanh
{
    public partial class DanhSach : Form
    {
        //Insert, update command
        const byte addCommand = 0;
        const byte updateCommand = 1;

        DataSet ds = new DataSet();
        NguyenLieuLogic nguyenLieuLogic = new NguyenLieuLogic();
        NhaCungCapLogic nhaCungCapLogic = new NhaCungCapLogic();
        MaGiamGiaLogic maGiamGiaLogic = new MaGiamGiaLogic();
        NhanVienLogic nhanVienLogic = new NhanVienLogic();
        DonHangLogic donHangLogic = new DonHangLogic();
        public bool QuyenCRUD;
        public DanhSach(bool quyenCRUD)
        {
            this.QuyenCRUD = quyenCRUD;
            InitializeComponent();
        }


        public void CapNhatQuyen(bool quyenCRUD)
        {
            if (!quyenCRUD)
            {
                //Disable CRUD: NguyenLieu
                btnThem_NL.Enabled = false;
                btnSua_NL.Enabled = false;
                btnXoa_NL.Enabled = false;

                //Disable CRUD: NhanVien

            }
        }

        private void DataBind()
        {
            /*ds = db.getChuyenBays();
            dgvChuyenBay.DataSource = ds.Tables[0];
            txtTimTatCa_NL.DataBindings.Clear();
            txtTimTatCa_NL.DataBindings.Add("Text", ds.Tables[0], "Mã chuyến bay");*/
        }
        private void DanhSach_Load(object sender, EventArgs e)
        {
            CapNhatQuyen(this.QuyenCRUD);
            setDgvNhaCungCap();
            setDgvNguyenLieu();
            setDgvMaGiamGia();
            setDgvNhanVien();
            setDgvDonHang();
            DataBind();

        }

        //Điều chỉnh độ cao từng hàng của một DataGridView
        private void setRowHeight(DataGridView dgv, int h)
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                row.Height = h;
            }
        }

        void ClearTextBoxes(Control parent)
        {
            foreach (Control child in parent.Controls)
            {
                TextBox textBox = child as TextBox;
                if (textBox == null)
                    ClearTextBoxes(child);
                else
                    textBox.Text = string.Empty;
            }
        }

        void ClearRadioButtons(Control parent)
        {
            foreach (Control child in parent.Controls)
            {
                RadioButton rdb = child as RadioButton;
                if (rdb == null)
                    ClearRadioButtons(child);
                else
                    rdb.Checked = false;
            }
        }



        /* -----------------------------------------------------> NGUYÊN LIỆU ----------------------------------------------------->*/

        //Lấy toàn bộ dữ liệu của table NguyenLieu gắn lên dgv, điều chỉnh dgv
        private void setDgvNguyenLieu()
        {
            //Bind data
            dgvNguyenLieu.AutoGenerateColumns = false;
            var listNguyenLieu = nguyenLieuLogic.NguyenLieuList();
            dgvNguyenLieu.DataSource = listNguyenLieu;

            //Modify header
            dgvNguyenLieu.ColumnHeadersDefaultCellStyle.BackColor = Color.LemonChiffon;
            dgvNguyenLieu.EnableHeadersVisualStyles = false;

            foreach (DataGridViewColumn col in dgvNguyenLieu.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.HeaderCell.Style.Font = new Font("Arial", 17F, FontStyle.Bold, GraphicsUnit.Pixel);
            }

            //Modify cell style
            dgvNguyenLieu.DefaultCellStyle.Font = new Font("Candara", 15);

            //Modify columns
            dgvNguyenLieu.Columns[0].Width = 160;
            dgvNguyenLieu.Columns[1].Width = 200;
            dgvNguyenLieu.Columns[2].Width = 175;
            dgvNguyenLieu.Columns[3].Width = 120;
            dgvNguyenLieu.Columns[4].Width = 100;

            //Modify each row
            setRowHeight(dgvNguyenLieu, 35);
        }

        private void lockChoices_NguyenLieu(bool obj1, bool obj2, bool obj3, bool obj4, bool obj5)
        {
            
            txtMaNguyenLieu.Enabled = !obj1;
            txtTenNguyenLieu.Enabled = !obj2;
            txtMaNhaCungCap_NguyenLieu.Enabled = !obj3;
            txtFrom_NguyenLieu.Enabled = !obj4;
            txtTo_NguyenLieu.Enabled = !obj5;

            txtMaNguyenLieu.BackColor = obj1 ? Color.Silver : Color.White;
            txtTenNguyenLieu.BackColor = obj2 ? Color.Silver : Color.White;
            txtMaNhaCungCap_NguyenLieu.BackColor = obj3 ? Color.Silver : Color.White;
            txtFrom_NguyenLieu.BackColor = obj4 ? Color.Silver : Color.White;
            txtTo_NguyenLieu.BackColor = obj5 ? Color.Silver : Color.White;

        }
        private void txtTimTatCa_NL_Enter(object sender, EventArgs e)
        {
            txtTimTatCa_NL.Clear();
        }

        private void btnTim_NL_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_NL_Click(object sender, EventArgs e)
        {
            ClearTextBoxes(tabControl.SelectedTab);
            ClearRadioButtons(tabControl.SelectedTab);
            lockChoices_NguyenLieu(true, true, true, true, true);
            txtTimTatCa_NL.Text = "Nhập thông tin vào đây";
        }

        private void btnThem_NL_Click(object sender, EventArgs e)
        {
            var frmNguyenLieu = new formNguyenLieu(addCommand, null);
            frmNguyenLieu.Show();
        }

        private void btnSua_NL_Click(object sender, EventArgs e)
        {
            //Mở formNguyenLieu và hiển thị thông tin của nguyên liệu đã chọn lên form

            //Lấy mã nguyên liệu đã chọn
            string maNguyenLieu = "";

            foreach (DataGridViewRow row in dgvNguyenLieu.SelectedRows)
            {
                maNguyenLieu = row.Cells[0].Value.ToString();
            }

            var frmNguyenLieu = new formNguyenLieu(updateCommand, maNguyenLieu) ;
            frmNguyenLieu.Show();
        }

        private void btnXoa_NL_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_NL_Click(object sender, EventArgs e)
        {
            setDgvNguyenLieu();
        }

        private void btnTimThongThuong_NL_Click(object sender, EventArgs e)
        {
            dgvNguyenLieu.DataBindings.Clear();
            string ex = "";

            var listNguyenLieu = new List<NguyenLieu>();

            //Tìm theo mã nguyên liệu
            if (rbMaNguyenLieu.Checked)
            {
                listNguyenLieu = nguyenLieuLogic.timThongThuong(0, txtMaNguyenLieu.Text, ref ex);
            }
            //Tìm theo tên nguyên liệu
            else if (rbTenNguyenLieu.Checked)
            {
                listNguyenLieu = nguyenLieuLogic.timThongThuong(1, txtTenNguyenLieu.Text, ref ex);
            }
            //Tìm theo mã nhà cung cấp
            else if (rbMaNhaCungCap.Checked)
            {
                listNguyenLieu = nguyenLieuLogic.timThongThuong(2, txtMaNhaCungCap_NguyenLieu.Text, ref ex);
            }

            //Gắn dữ liệu lên dgv 
            dgvNguyenLieu.DataSource = listNguyenLieu;
            setRowHeight(dgvNguyenLieu, 35);
        }

        private void btnTimNangCao_NL_Click(object sender, EventArgs e)
        {
            dgvNguyenLieu.DataBindings.Clear();
            string ex = "";

            var listNguyenLieu = new List<NguyenLieu>();
            var soLuongTu = int.Parse(txtFrom_NguyenLieu.Text);
            var soLuongDen = int.Parse(txtTo_NguyenLieu.Text);

            //Tìm theo số lượng còn lại
            if (rbSoLuongConLai.Checked)
            {
                listNguyenLieu = nguyenLieuLogic.timNangCao(0, soLuongTu, soLuongDen, ref ex);
            }
            //Tìm theo đơn giá
            else if (rbDonGiaNguyenLieu.Checked)
            {
                listNguyenLieu = nguyenLieuLogic.timNangCao(1, soLuongTu, soLuongDen, ref ex);
            }

            //Gắn dữ liệu lên dgv
            dgvNguyenLieu.DataSource = listNguyenLieu;
            setRowHeight(dgvNguyenLieu, 35);
        }

        private void rbMaNguyenLieu_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NguyenLieu(false, true, true, true, true);
        }

        private void rbTenNguyenLieu_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NguyenLieu(true, false, true, true, true);

        }

        private void rbMaNhaCungCap_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NguyenLieu(true, true, false, true, true);

        }

        private void rbSoLuongConLai_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NguyenLieu(true, true, true, false, false);

        }

        private void rbDonGiaNguyenLieu_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NguyenLieu(true, true, true, false, false);

        }
        /* -----------------------------------------------------> NGUYÊN LIỆU ----------------------------------------------------->*/


        /* -----------------------------------------------------> NHÂN VIÊN ----------------------------------------------------->*/
        private void lockChoices_NhanVien(bool obj1, bool obj2, bool obj3, bool obj4, bool obj5, bool obj6, bool obj7)
        {
            txtMaNhanVien.Enabled = !obj1;
            txtTenNhanVien.Enabled = !obj2;
            txtFrom_NhanVien.Enabled = !obj6;
            txtTo_NhanVien.Enabled = !obj7;

            txtMaNhanVien.BackColor = obj1 ? Color.Silver : Color.White;
            txtTenNhanVien.BackColor = obj2 ? Color.Silver : Color.White;
            cbGioiTinh.BackColor = obj3 ? Color.Silver : Color.White; ;
            cbLoai.BackColor = obj4 ? Color.Silver : Color.White;
            cbChucVu.BackColor = obj5 ? Color.Silver : Color.White;
            txtFrom_NhanVien.BackColor = obj6 ? Color.Silver : Color.White;
            txtTo_NhanVien.BackColor = obj7 ? Color.Silver : Color.White;

        }

        private void setDgvNhanVien()
        {
            //Bind data
            dgvNhanVien.AutoGenerateColumns = false;
            var listNhanVien = nhanVienLogic.NhanVienList();
            dgvNhanVien.DataSource = listNhanVien;

            //Modify header
            dgvNhanVien.ColumnHeadersDefaultCellStyle.BackColor = Color.LemonChiffon;
            dgvNhanVien.EnableHeadersVisualStyles = false;

            foreach (DataGridViewColumn col in dgvNhanVien.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.HeaderCell.Style.Font = new Font("Arial", 17F, FontStyle.Bold, GraphicsUnit.Pixel);
            }

            //Modify cell style
            dgvNguyenLieu.DefaultCellStyle.Font = new Font("Candara", 15);

            //Modify columns
            dgvNhanVien.Columns[0].Width = 100;
            dgvNhanVien.Columns[1].Width = 200;
            dgvNhanVien.Columns[2].Width = 100;
            dgvNhanVien.Columns[3].Width = 100;
            dgvNhanVien.Columns[4].Width = 130;
            dgvNhanVien.Columns[5].Width = 130;

            //Modify each row
            setRowHeight(dgvNhanVien, 35);

            //Mapping row value
            foreach (DataGridViewRow row in dgvNhanVien.Rows)
            {
                row.Cells["GioiTinhStr"].Value = nhanVienLogic.ToStringGT(row.Cells["GioiTinhInt"].Value.ToString());
                row.Cells["LoaiNVStr"].Value = nhanVienLogic.ToStringLoai(row.Cells["LoaiNVInt"].Value.ToString());
                row.Cells["ChucVuStr"].Value = nhanVienLogic.ToStringChucVu(row.Cells["ChucVuInt"].Value.ToString());
            }
        }
        private void txtTimTatCa_NhanVien_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_NhanVien_Click(object sender, EventArgs e)
        {
                
        }

        private void btnReset_NhanVien_Click(object sender, EventArgs e)
        {

            ClearTextBoxes(tabControl.SelectedTab);
            ClearRadioButtons(tabControl.SelectedTab);
            lockChoices_NhanVien(true, true, true, true, true,true, true);
            txtTimTatCa_NL.Text = "Nhập thông tin vào đây";
        }

        private void btnThem_NhanVien_Click(object sender, EventArgs e)
        {
            var frmNhanVien = new formNhanVien();
            frmNhanVien.Show();

        }

        private void btnSua_NhanVien_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_NhanVien_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_NhanVien_Click(object sender, EventArgs e)
        {
            setDgvNhanVien();
        }

        private void btnTimThongThuong_NhanVien_Click(object sender, EventArgs e)
        {
            dgvNhanVien.DataBindings.Clear();
            string ex = "";

            var listNhanVien = new List<NhanVien>();

            //Tìm theo mã nhân viên
            if (rbMaNhanVien.Checked)
            {
                listNhanVien = nhanVienLogic.timThongThuong(0, txtMaNhanVien.Text, ref ex);
            }
            //Tìm theo tên nhân viên 
            else if (rbTenNhanVien.Checked)
            {
                listNhanVien = nhanVienLogic.timThongThuong(1, txtTenNhanVien.Text, ref ex);
            }
            //Tìm theo giới tính 
            else if (true)
            {
              
                listNhanVien = nhanVienLogic.timThongThuong(2, cbGioiTinh.Text, ref ex);
            }

            //Gắn dữ liệu lên dgv 
            dgvNhanVien.DataSource = listNhanVien;
            setRowHeight(dgvNhaCungCap, 35);
        }

        private void btnTimNangCao_NhanVien_Click(object sender, EventArgs e)
        {
            dgvNhanVien.DataBindings.Clear();
            string ex = "";

            var listNhanVien = new List<NhanVien>();

            //Tìm theo lương
            if (rbLuongTheoGio.Checked)
            {
                listNhanVien = nhanVienLogic.timNangCao(0,txtFrom_NhanVien.Text,txtTo_NhanVien.Text , ref ex);
            }
            //Tìm theo kiểu nhân viên full-time hay là part-time 
            else if (rbLoai.Checked)
            {
                listNhanVien = nhanVienLogic.timNangCao(1, cbLoai.Text,cbLoai.Text, ref ex);
            }
            //Tìm theo chức vụ
            else if (rbChucVu.Checked)
            {

                listNhanVien = nhanVienLogic.timNangCao(2, cbChucVu.Text,cbChucVu.Text, ref ex);
            }

            //Gắn dữ liệu lên dgv 
            dgvNhanVien.DataSource = listNhanVien;
            setRowHeight(dgvNhaCungCap, 35);
        }

        private void rbMaNhanVien_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NhanVien(false, true, true, true, true, true, true);
        }

        private void rdTenNhanVien_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NhanVien(true, false, true, true, true, true, true);
        }

        private void rbGioiTinh_CheckedChanged_1(object sender, EventArgs e)
        {
            lockChoices_NhanVien(true, true, false, true, true, true, true);

        }

        private void rbLuongTheoGio_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NhanVien(true, true, true, true, true, false, false);
        }

        private void rbLoai_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NhanVien(true, true, true, false, true, true, true);
        }

        private void rbChucVu_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NhanVien(true, true, true, true, false, true, true);
        }
        /* -----------------------------------------------------> NHÂN VIÊN ----------------------------------------------------->*/


        /* -----------------------------------------------------> NHÀ CUNG CẤP ----------------------------------------------------->*/
        private void lockChoices_NhaCungCap(bool obj1, bool obj2, bool obj3)
        {
            txtMaNhaCungCap_NhaCungCap.Enabled = !obj1;
            txtTenNhaCungCap.Enabled = !obj2;
            txtDiaChi.Enabled = !obj3;

            txtMaNhaCungCap_NhaCungCap.BackColor = obj1 ? Color.Silver : Color.White;
            txtTenNhaCungCap.BackColor = obj2 ? Color.Silver : Color.White;
            txtDiaChi.BackColor = obj3 ? Color.Silver : Color.White;

        }

        private void setDgvNhaCungCap()
        {
            //Bind data
            dgvNhaCungCap.AutoGenerateColumns = false;
            var listNhaCungCap = nhaCungCapLogic.NhaCungCapList();
            dgvNhaCungCap.DataSource = listNhaCungCap;

            //Modify header
            dgvNhaCungCap.ColumnHeadersDefaultCellStyle.BackColor = Color.LemonChiffon;
            dgvNhaCungCap.EnableHeadersVisualStyles = false;
            foreach (DataGridViewColumn col in dgvNhaCungCap.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.HeaderCell.Style.Font = new Font("Arial", 17F, FontStyle.Bold, GraphicsUnit.Pixel);
            }

            //Modify cell style
            dgvNhaCungCap.DefaultCellStyle.Font = new Font("Candara", 15);

            //Modify columns
            dgvNhaCungCap.Columns[0].Width = 150;
            dgvNhaCungCap.Columns[1].Width = 300;
            dgvNhaCungCap.Columns[2].Width = 560;

            //Modify each row
            setRowHeight(dgvNhaCungCap, 35);
        }
            private void txtTimTatCa_NhaCungCap_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_NhaCungCap_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_NhaCungCap_Click(object sender, EventArgs e)
        {
            ClearTextBoxes(tabControl.SelectedTab);
            ClearRadioButtons(tabControl.SelectedTab);
            lockChoices_NhaCungCap(true, true, true);
            txtTimTatCa_NL.Text = "Nhập thông tin vào đây";
        }

        private void btnThem_NhaCungCap_Click(object sender, EventArgs e)
        {
            var frmNhaCungCap = new formNhaCungCap();
            frmNhaCungCap.Show();
        }

        private void btnSua_NhaCungCap_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_NhaCungCap_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_NhaCungCap_Click(object sender, EventArgs e)
        {
            setDgvNhaCungCap();
        }

        private void btnTimThongThuong_NhaCungCap_Click(object sender, EventArgs e)
        {
            dgvNhaCungCap.DataBindings.Clear();
            string ex = "";

            var listNhaCungCap = new List<NhaCungCap>();

            //Tìm theo mã nguyên liệu
            if (rbNhaCungCap.Checked)
            {
                listNhaCungCap = nhaCungCapLogic.timThongThuong(0, txtMaNhaCungCap_NhaCungCap.Text, ref ex);
            }
            //Tìm theo tên nguyên liệu
            else if (rbTenNhaCungCap.Checked)
            {
                listNhaCungCap = nhaCungCapLogic.timThongThuong(1, txtTenNhaCungCap.Text, ref ex);
            }
            //Tìm theo mã nhà cung cấp
            else if (rbDiaChi.Checked)
            {
                listNhaCungCap = nhaCungCapLogic.timThongThuong(2, txtDiaChi.Text, ref ex);
            }

            //Gắn dữ liệu lên dgv 
            dgvNhaCungCap.DataSource = listNhaCungCap;
            setRowHeight(dgvNhaCungCap, 35);
        }

        private void rbNhaCungCap_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NhaCungCap(false, true, true);

        }

        private void rbTenNhaCungCap_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_NhaCungCap(true, false, true);
        }


        private void rbDiaChi_CheckedChanged(object sender, EventArgs e)
        {

            lockChoices_NhaCungCap(true, true, false);
        }

        /* -----------------------------------------------------> NHÀ CUNG CẤP ----------------------------------------------------->*/


        /* -----------------------------------------------------> SẢN PHẨM ----------------------------------------------------->*/
        private void lockChoices_SanPham(bool obj1, bool obj2, bool obj3, bool obj4, bool obj5, bool obj6)
        {

            txtMaSanPham.Enabled = !obj1;
            txtTenSanPham.Enabled = !obj2;
            txtFrom_SanPham.Enabled = !obj3;
            txtTo_SanPham.Enabled = !obj4;
            dtpFrom_SanPham.Enabled = !obj5;
            dtpTo_SanPham.Enabled = !obj6;

            txtMaSanPham.BackColor = obj1 ? Color.Silver : Color.White;
            txtTenSanPham.BackColor = obj2 ? Color.Silver : Color.White;
            txtFrom_SanPham.BackColor = obj3 ? Color.Silver : Color.White;
            txtTo_SanPham.BackColor = obj4 ? Color.Silver : Color.White;

        }


        private void txtTimTatCa_SanPham_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_SanPham_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_SanPham_Click(object sender, EventArgs e)
        {

        }

        private void btnThem_SanPham_Click(object sender, EventArgs e)
        {
            var frmSanPham = new formSanPham();
            frmSanPham.Show();
        }

        private void btnSua_SanPham_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_SanPham_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_SanPham_Click(object sender, EventArgs e)
        {

        }

        private void btnTimThongThuong_SanPham_Click(object sender, EventArgs e)
        {

        }

        private void btnTimNangCao_SanPham_Click(object sender, EventArgs e)
        {

        }

        private void rbMaSanPham_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_SanPham(false, true, true, true, true, true);
        }

        private void rbTenSanPham_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_SanPham(true, false, true, true, true, true); ;
        }

        private void rbChiPhiSanXuat_CheckedChanged(object sender, EventArgs e)
        {

            lockChoices_SanPham(true, true, false, false, true, true);
        }

        private void rbDonGiaSanPham_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_SanPham(true, true, false, false, true, true);
        }

        private void rbSoLuongTon_SanPham_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_SanPham(true, true, false, false, true, true);
        }

        private void rbSoLuongDaBan_SanPham_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_SanPham(true, true, false, false, true, true);
        }

        private void rbNgayCapNhat_SanPham_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_SanPham(true, true, true, true, false, false);
        }
        /* -----------------------------------------------------> SẢN PHẨM ----------------------------------------------------->*/


        /* -----------------------------------------------------> LỊCH LÀM VIỆC ----------------------------------------------------->*/
        private void lockChoices_LichLamViec(bool obj1, bool obj2, bool obj3, bool obj4, bool obj5)
        {
            txtMaLichLamViec.Enabled = !obj1;
            txtMaNhanVien_LichLamViec.Enabled = !obj2;
            cbCaLam.Enabled = !obj3;
            dtpFrom_LichLamViec.Enabled = !obj4;
            dtpTo_LichLamViec.Enabled = !obj5;

            txtMaLichLamViec.BackColor = obj1 ? Color.Silver : Color.White;
            txtMaNhanVien_LichLamViec.BackColor = obj2 ? Color.Silver : Color.White;
            cbCaLam.BackColor = obj3 ? Color.Silver : Color.White;

        }


        private void txtTimTatCa_LichLamViec_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_LichLamViec_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_LichLamViec_Click(object sender, EventArgs e)
        {

        }

        private void btnThem_LichLamViec_Click(object sender, EventArgs e)
        {
            var frmLichLamViec = new formLichLamViec();
            frmLichLamViec.Show();
        }

        private void btnSua_LichLamViec_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_LichLamViec_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_LichLamViec_Click(object sender, EventArgs e)
        {

        }

        private void btnTimThongThuong_LichLamViec_Click(object sender, EventArgs e)
        {

        }

        private void btnTimNangCao_LichLamViec_Click(object sender, EventArgs e)
        {

        }

        private void rbMaLichLamViec_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_LichLamViec(false, true, true, true, true);
        }

        private void rbMaNhanVien_LichLamViec_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_LichLamViec(true, false, true, true, true);
        }

        private void rbCaLam_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_LichLamViec(true, true, false, true, true);
        }

        private void rbThoiGian_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_LichLamViec(true, true, true, false, false);

        }


        /* -----------------------------------------------------> LỊCH LÀM VIỆC ----------------------------------------------------->*/


        /* -----------------------------------------------------> MÃ GIẢM GIÁ ----------------------------------------------------->*/
        private void lockChoices_MaGiamGia(bool obj1, bool obj2, bool obj3)
        {
            txtMaGiamGia.Enabled = !obj1;
            txtFrom_MaGiamGia.Enabled = !obj2;
            txtTo_MaGiamGia.Enabled = !obj3;

            txtMaGiamGia.BackColor = obj1 ? Color.Silver : Color.White;
            txtFrom_MaGiamGia.BackColor = obj2 ? Color.Silver : Color.White;
            txtTo_MaGiamGia.BackColor = obj3 ? Color.Silver : Color.White;



        }
        private void setDgvMaGiamGia()
        {
            //Bind data
            dgvMaGiamGia.AutoGenerateColumns = false;
            var listMaGiamGia = maGiamGiaLogic.MaGiamGiaList();
            dgvMaGiamGia.DataSource = listMaGiamGia;

            //Modify header
            dgvMaGiamGia.ColumnHeadersDefaultCellStyle.BackColor = Color.LemonChiffon;
            dgvMaGiamGia.EnableHeadersVisualStyles = false;
            foreach (DataGridViewColumn col in dgvMaGiamGia.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.HeaderCell.Style.Font = new Font("Arial", 17F, FontStyle.Bold, GraphicsUnit.Pixel);
            }

            //Modify cell style
            dgvMaGiamGia.DefaultCellStyle.Font = new Font("Candara", 15);

            //Modify columns
            dgvMaGiamGia.Columns[0].Width = 150;
            dgvMaGiamGia.Columns[1].Width = 300;
            dgvMaGiamGia.Columns[2].Width = 560;

            //Modify each row
            setRowHeight(dgvMaGiamGia, 35);
        }

        private void txtTimTatCa_MaGiamGia_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_MaGiamGia_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_MaGiamGia_Click(object sender, EventArgs e)
        {
            ClearRadioButtons(tabControl.SelectedTab);
            ClearTextBoxes(tabControl.SelectedTab);
            lockChoices_MaGiamGia(true, true, true);
            txtTimTatCa_MaGiamGia.Text = "Nhập mã giảm giá vào đây ";
        }

        private void btnThem_MaGiamGia_Click(object sender, EventArgs e)
        {
            var frmMaGiamGia = new formMaGiamGia();
            frmMaGiamGia.Show();
        }

        private void btnSua_MaGiamGia_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_MaGiamGia_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_MaGiamGia_Click(object sender, EventArgs e)
        {
            setDgvMaGiamGia();
        }

        private void btnTimThongThuong_MaGiamGia_Click(object sender, EventArgs e)
        {
            dgvMaGiamGia.DataBindings.Clear();
            var listMaGiamGia = new List<MaGiamGia>();
            string ex = "";
            if (rbMaGiamGia.Checked)
            {
                //Tìm theo mã giảm giá 
                listMaGiamGia = maGiamGiaLogic.timThongThuong(0, txtMaGiamGia.Text,ref ex);
            }
            
            dgvMaGiamGia.DataSource = listMaGiamGia;
            setRowHeight(dgvMaGiamGia, 35);
        }

        private void btnTimNangCao_MaGiamGia_Click(object sender, EventArgs e)
        {
            dgvMaGiamGia.DataBindings.Clear();
            var listMaGiamGia = new List<MaGiamGia>();
            string ex = "";
            int from = int.Parse(txtFrom_MaGiamGia.Text);
            int to = int.Parse(txtTo_MaGiamGia.Text);
            if (rbSoTienGiam.Checked)
            {
                //Tìm theo số tiền giảm 
                listMaGiamGia = maGiamGiaLogic.timNangCao(0, from, to, ref ex);
            }
            if (rbSoLuong_MaGiamGia.Checked)
            {
                //Tìm theo số tiền giảm 
                listMaGiamGia = maGiamGiaLogic.timNangCao(1, from, to, ref ex);
            }
            dgvMaGiamGia.DataSource = listMaGiamGia;
            setRowHeight(dgvMaGiamGia, 35);
        }

        private void rbMaGiamGia_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_MaGiamGia(false, true, true);
        }

        private void rbSoTienGiam_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_MaGiamGia(true, false, false);
        }

        private void rbSoLuong_MaGiamGia_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_MaGiamGia(true, false, false);
        }
        /* -----------------------------------------------------> MÃ GIẢM GIÁ ----------------------------------------------------->*/




        /* -----------------------------------------------------> ĐƠN HÀNG  ----------------------------------------------------->*/
        private void lockChoices_DonHang(bool obj1, bool obj2, bool obj3, bool obj4, bool obj5, bool obj6, bool obj7)
        {
            txtMaDonHang_DonHang.Enabled = !obj1;
            txtMaNhanVien_DonHang.Enabled = !obj2;
            txtMaGiamGia_DonHang.Enabled = !obj3;
            txtFrom_DonHang.Enabled = !obj4;
            txtTo_DonHang.Enabled = !obj5;
            dtpFrom_DonHang.Enabled = !obj6;
            dtpTo_DonHang.Enabled = !obj7;

            txtMaDonHang_DonHang.BackColor = obj1 ? Color.Silver : Color.White;
            txtMaNhanVien_DonHang.BackColor = obj2 ? Color.Silver : Color.White;
            txtMaGiamGia_DonHang.BackColor = obj3 ? Color.Silver : Color.White;
            txtFrom_DonHang.BackColor = obj4 ? Color.Silver : Color.White;
            txtTo_DonHang.BackColor = obj5 ? Color.Silver : Color.White;
        }

        private void setDgvDonHang()
        {
            //Bind data
            dgvDonHang.AutoGenerateColumns = false;
            var listDonHang = donHangLogic.DonHangList();
            dgvDonHang.DataSource = listDonHang ;

            //Modify header
            dgvDonHang.ColumnHeadersDefaultCellStyle.BackColor = Color.LemonChiffon;
            dgvDonHang.EnableHeadersVisualStyles = false;
            foreach (DataGridViewColumn col in dgvDonHang.Columns)
            {
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.HeaderCell.Style.Font = new Font("Arial", 17F, FontStyle.Bold, GraphicsUnit.Pixel);
            }

            //Modify cell style
            dgvDonHang.DefaultCellStyle.Font = new Font("Candara", 15);

            //Modify columns
            dgvDonHang.Columns[0].Width = 100;
            dgvDonHang.Columns[1].Width = 300;
            dgvDonHang.Columns[2].Width = 200;
            dgvDonHang.Columns[3].Width = 200;
            dgvDonHang.Columns[4].Width = 210;


            //Modify each row
            setRowHeight(dgvDonHang, 50);
        }

        private void txtTimTatCa_DonHang_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_DonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_DonHang_Click(object sender, EventArgs e)
        {
            ClearRadioButtons(tabControl.SelectedTab);
            ClearTextBoxes(tabControl.SelectedTab);
            lockChoices_DonHang(true, true, true, true, true, true, true);
            txtTimTatCa_DonHang.Text = "Nhập thông tin đơn hàng vào đây ";
        }

        private void btnThem_DonHang_Click(object sender, EventArgs e)
        {
            var frmDonHang = new formTaoDonHang();
            frmDonHang.Show();
        }

        
        private void btnSua_DonHang_Click(object sender, EventArgs e)
        //Mở formDonHang và hiển thị thông tin chi tiết đơn hàng đã chọn lên form
        {

            //Lấy mã đơn hàng đã chọn
            string maDonHang = "";

            foreach (DataGridViewRow row in dgvDonHang.SelectedRows)
            {
                maDonHang = row.Cells[0].Value.ToString();
            }

            var frmDonHang = new formDonHang(maDonHang);
            frmDonHang.Show();
        }

        private void btnXoa_DonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_DonHang_Click(object sender, EventArgs e)
        {
            setDgvDonHang();
        }

        private void btnTimThongThuong_DonHang_Click(object sender, EventArgs e)
        {
            dgvDonHang.DataBindings.Clear();
            string ex = "";

            var listDonHang = new List<DonHangMua>();

            //Tìm theo mã nguyên liệu
            if (rbMaDonHang_DonHang.Checked)
            {
                listDonHang = donHangLogic.timThongThuong(0, txtMaDonHang_DonHang.Text, ref ex);
            }
            //Tìm theo mã nhân viên
            else if (rbMaNhanVien_DonHang.Checked)
            {
                listDonHang = donHangLogic.timThongThuong(1, txtMaNhanVien_DonHang.Text, ref ex);
            }
            //Tìm theo mã giảm giá
            else if (rbMaGiamGia_DonHang.Checked)
            {
                listDonHang = donHangLogic.timThongThuong(2, txtMaGiamGia_DonHang.Text, ref ex);
            }

            //Gắn dữ liệu lên dgv 
            dgvDonHang.DataSource = listDonHang;
            setRowHeight(dgvDonHang, 50);
        }

        private void btnTimNangCao_DonHang_Click(object sender, EventArgs e)
        {
            dgvDonHang.DataBindings.Clear();
            var listDonHang = new List<DonHangMua>();
            string ex = "";
            int from = txtFrom_DonHang.Text != "" ? int.Parse(txtFrom_DonHang.Text) : 0;
            int to = txtTo_DonHang.Text != "" ? int.Parse(txtTo_DonHang.Text) : 0;
            DateTime start_date = dtpFrom_DonHang.Value;
            DateTime end_date = dtpTo_DonHang.Value;
            if (rbTongGiaTri_DonHang.Checked)
            {
                //Tìm theo số tiền giảm 
                listDonHang = donHangLogic.timNangCao(0, from, to, new DateTime(), new DateTime(), ref ex);
            }
            if (rbNgayTao_DonHang.Checked)
            {
                //Tìm theo số tiền giảm 
                listDonHang = donHangLogic.timNangCao(1, 0, 0, start_date, end_date, ref ex);
            }
            dgvDonHang.DataSource = listDonHang;
            setRowHeight(dgvDonHang, 50);
        }

        private void rbMaDonHang_DonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_DonHang(false, true, true, true, true, true, true);
        }

        private void rbMaNhanVien_DonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_DonHang(true, false, true, true, true, true, true);
        }

        private void rbMaGiamGia_DonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_DonHang(true, true, false, true, true, true, true);
        }

        private void rbTongGiaTri_DonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_DonHang(true, true, true, false, false, true, true);
        }

        private void rbNgayTao_DonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_DonHang(true, true, true, true, true, false, false);
        }
        /* -----------------------------------------------------> ĐƠN HÀNG  ----------------------------------------------------->*/





        /* -----------------------------------------------------> CHI TIẾT ĐƠN HÀNG  ----------------------------------------------------->*/
        private void lockChoices_ChiTietDonHang(bool obj1, bool obj2, bool obj3, bool obj4, bool obj5, bool obj6, bool obj7)
        {
            txtMaDonHang_ChiTietDonHang.Enabled = !obj1;
            txtMaNhanVien_ChiTietDonHang.Enabled = !obj2;
            txtMaGiamGia_ChiTietDonHang.Enabled = !obj3;
            txtFrom_ChiTietDonHang.Enabled = !obj4;
            txtTo_ChiTietDonHang.Enabled = !obj5;
            dtpFrom_ChiTietDonHang.Enabled = !obj6;
            dtpTo_ChiTietDonHang.Enabled = !obj7;

            txtMaDonHang_ChiTietDonHang.BackColor = obj1 ? Color.Silver : Color.White;
            txtMaNhanVien_ChiTietDonHang.BackColor = obj2 ? Color.Silver : Color.White;
            txtMaGiamGia_ChiTietDonHang.BackColor = obj3 ? Color.Silver : Color.White;
            txtFrom_ChiTietDonHang.BackColor = obj4 ? Color.Silver : Color.White;
            txtTo_ChiTietDonHang.BackColor = obj5 ? Color.Silver : Color.White;
        }

        private void txtTimTatCa_ChiTietDonHang_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnThem_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnSua_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnTimThongThuong_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void btnTimNangCao_ChiTietDonHang_Click(object sender, EventArgs e)
        {

        }

        private void rbMaDonHang_ChiTietDonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_ChiTietDonHang(false, true, true, true, true, true, true);
        }

        private void rbMaNhanVien_ChiTietDonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_ChiTietDonHang(true, false, true, true, true, true, true);
        }

        private void rbMaGiamGia_ChiTietDonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_ChiTietDonHang(true, true, false, true, true, true, true);
        }

        private void rbTongGiaTri_ChiTietDonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_ChiTietDonHang(true, true, true, false, false, true, true);
        }

        private void rbSoLuong_ChiTietDonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_ChiTietDonHang(true, true, true, false, false, true, true);
        }

        private void rbGiaBanSanPham_ChiTietDonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_ChiTietDonHang(true, true, true, false, false, true, true);
        }

        private void rbNgayTao_ChiTietDonHang_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_ChiTietDonHang(true, true, true, true, true, false, false);
        }
        /* -----------------------------------------------------> CHI TIẾT ĐƠN HÀNG  ----------------------------------------------------->*/




        /* -----------------------------------------------------> DOANH THU  ----------------------------------------------------->*/
        private void lockChoices_DoanhThu(bool obj1, bool obj2, bool obj3, bool obj4)
        {
            txtFrom_DoanhThu.Enabled = !obj1;
            txtTo_DoanhThu.Enabled = !obj2;
            dtpThoiGian_DoanhThu.Enabled = !obj3;
            dtpTo_DoanhThu.Enabled = !obj4;

            txtFrom_DoanhThu.BackColor = obj1 ? Color.Silver : Color.White;
            txtTo_DoanhThu.BackColor = obj2 ? Color.Silver : Color.White;
        }

        private void txtTimTatCa_DoanhThu_Enter(object sender, EventArgs e)
        {

        }

        private void btnTim_DoanhThu_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_DoanhThu_Click(object sender, EventArgs e)
        {

        }

        private void btnThem_DoanhThu_Click(object sender, EventArgs e)
        {

        }

        private void btnSua_DoanhThu_Click(object sender, EventArgs e)
        {

        }

        private void btnXoa_DoanhThu_Click(object sender, EventArgs e)
        {

        }

        private void btnReload_DoanhThu_Click(object sender, EventArgs e)
        {

        }

        private void btnTimThongThuong_DoanhThu_Click(object sender, EventArgs e)
        {

        }

        private void rbTongDoanhThu_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_DoanhThu(false, false, true, true);

        }

        private void rbNgay_DoanhThu_CheckedChanged(object sender, EventArgs e)
        {
            lockChoices_DoanhThu(true, true, false, false);
        }

        private void rbGioiTinh_CheckedChanged(object sender, EventArgs e)
        {
            rbGioiTinh.BackColor = rbGioiTinh.Checked ? Color.White : Color.Silver;
        }

        private void dgvNhaCungCap_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvNguyenLieu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void rbGioiTinh_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbLoai_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        
        /* -----------------------------------------------------> DOANH THU  ----------------------------------------------------->*/

    }
}
