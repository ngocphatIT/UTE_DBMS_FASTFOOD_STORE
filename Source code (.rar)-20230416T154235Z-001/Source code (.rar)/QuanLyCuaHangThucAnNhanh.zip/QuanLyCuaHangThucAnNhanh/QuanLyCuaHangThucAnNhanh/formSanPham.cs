﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyCuaHangThucAnNhanh
{
	public partial class formSanPham : Form
	{
		public formSanPham()
		{
			InitializeComponent();
		}

		private void chkDaXoa_CheckedChanged(object sender, EventArgs e)
		{

		}
	}
}
