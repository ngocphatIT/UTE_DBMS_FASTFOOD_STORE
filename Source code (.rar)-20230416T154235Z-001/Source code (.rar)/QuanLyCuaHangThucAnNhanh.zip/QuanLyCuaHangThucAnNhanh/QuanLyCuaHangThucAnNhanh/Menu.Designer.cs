﻿
namespace QuanLyCuaHangThucAnNhanh
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.txtQuyenHan = new System.Windows.Forms.TextBox();
            this.txtNguoiDangDangNhap = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnNhaCungCap = new System.Windows.Forms.Button();
            this.btnSanPham = new System.Windows.Forms.Button();
            this.btnNguyenLieu = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnTaoDonHang = new System.Windows.Forms.Button();
            this.btnDoanhThu = new System.Windows.Forms.Button();
            this.btnChiTietDonHang = new System.Windows.Forms.Button();
            this.btnDonHang = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnMaGiamGia = new System.Windows.Forms.Button();
            this.btnLichLamViec = new System.Windows.Forms.Button();
            this.btnNhanVien = new System.Windows.Forms.Button();
            this.panelMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelMenu.Controls.Add(this.txtQuyenHan);
            this.panelMenu.Controls.Add(this.txtNguoiDangDangNhap);
            this.panelMenu.Controls.Add(this.label3);
            this.panelMenu.Controls.Add(this.label2);
            this.panelMenu.Controls.Add(this.btnThoat);
            this.panelMenu.Controls.Add(this.btnDangXuat);
            this.panelMenu.Controls.Add(this.label1);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(928, 107);
            this.panelMenu.TabIndex = 0;
/*            this.panelMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMenu_Paint);
*/            // 
            // txtQuyenHan
            // 
            this.txtQuyenHan.Enabled = false;
            this.txtQuyenHan.ForeColor = System.Drawing.Color.Red;
            this.txtQuyenHan.Location = new System.Drawing.Point(27, 76);
            this.txtQuyenHan.Margin = new System.Windows.Forms.Padding(2);
            this.txtQuyenHan.Name = "txtQuyenHan";
            this.txtQuyenHan.Size = new System.Drawing.Size(134, 20);
            this.txtQuyenHan.TabIndex = 3;
            // 
            // txtNguoiDangDangNhap
            // 
            this.txtNguoiDangDangNhap.Enabled = false;
            this.txtNguoiDangDangNhap.ForeColor = System.Drawing.Color.Blue;
            this.txtNguoiDangDangNhap.Location = new System.Drawing.Point(27, 29);
            this.txtNguoiDangDangNhap.Margin = new System.Windows.Forms.Padding(2);
            this.txtNguoiDangDangNhap.Name = "txtNguoiDangDangNhap";
            this.txtNguoiDangDangNhap.Size = new System.Drawing.Size(134, 20);
            this.txtNguoiDangDangNhap.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(9, 52);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quyền hạn:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(9, 7);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tài khoản hiện tại:";
            // 
            // btnThoat
            // 
            this.btnThoat.AutoSize = true;
            this.btnThoat.BackColor = System.Drawing.Color.White;
            this.btnThoat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnThoat.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold);
            this.btnThoat.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.exit35;
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat.Location = new System.Drawing.Point(783, 36);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(2);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(125, 47);
            this.btnThoat.TabIndex = 1;
            this.btnThoat.Text = "  Thoát";
            this.btnThoat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.AutoSize = true;
            this.btnDangXuat.BackColor = System.Drawing.Color.White;
            this.btnDangXuat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDangXuat.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold);
            this.btnDangXuat.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.logout35;
            this.btnDangXuat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDangXuat.Location = new System.Drawing.Point(618, 36);
            this.btnDangXuat.Margin = new System.Windows.Forms.Padding(2);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(151, 47);
            this.btnDangXuat.TabIndex = 1;
            this.btnDangXuat.Text = "  Đăng xuất";
            this.btnDangXuat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDangXuat.UseVisualStyleBackColor = false;
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.loginIcon75;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(303, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "     Trang chủ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnNhaCungCap);
            this.panel2.Controls.Add(this.btnSanPham);
            this.panel2.Controls.Add(this.btnNguyenLieu);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 107);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 330);
            this.panel2.TabIndex = 4;
            // 
            // btnNhaCungCap
            // 
            this.btnNhaCungCap.BackColor = System.Drawing.SystemColors.Control;
            this.btnNhaCungCap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNhaCungCap.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNhaCungCap.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhaCungCap.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.nhaCungCap481;
            this.btnNhaCungCap.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNhaCungCap.Location = new System.Drawing.Point(0, 166);
            this.btnNhaCungCap.Name = "btnNhaCungCap";
            this.btnNhaCungCap.Size = new System.Drawing.Size(298, 83);
            this.btnNhaCungCap.TabIndex = 3;
            this.btnNhaCungCap.Text = "   NHÀ CUNG CẤP";
            this.btnNhaCungCap.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNhaCungCap.UseVisualStyleBackColor = false;
            this.btnNhaCungCap.Click += new System.EventHandler(this.btnNhaCungCap_Click);
            // 
            // btnSanPham
            // 
            this.btnSanPham.BackColor = System.Drawing.SystemColors.Control;
            this.btnSanPham.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSanPham.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSanPham.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanPham.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.SanPham48;
            this.btnSanPham.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSanPham.Location = new System.Drawing.Point(0, 83);
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.Size = new System.Drawing.Size(298, 83);
            this.btnSanPham.TabIndex = 2;
            this.btnSanPham.Text = "   SẢN PHẨM";
            this.btnSanPham.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSanPham.UseVisualStyleBackColor = false;
            this.btnSanPham.Click += new System.EventHandler(this.btnSanPham_Click);
            // 
            // btnNguyenLieu
            // 
            this.btnNguyenLieu.BackColor = System.Drawing.SystemColors.Control;
            this.btnNguyenLieu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNguyenLieu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNguyenLieu.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNguyenLieu.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.nguyenLieu50;
            this.btnNguyenLieu.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNguyenLieu.Location = new System.Drawing.Point(0, 0);
            this.btnNguyenLieu.Name = "btnNguyenLieu";
            this.btnNguyenLieu.Size = new System.Drawing.Size(298, 83);
            this.btnNguyenLieu.TabIndex = 1;
            this.btnNguyenLieu.Text = "   NGUYÊN LIỆU";
            this.btnNguyenLieu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNguyenLieu.UseVisualStyleBackColor = false;
            this.btnNguyenLieu.Click += new System.EventHandler(this.btnNguyenLieu_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.btnTaoDonHang);
            this.panel3.Controls.Add(this.btnDoanhThu);
            this.panel3.Controls.Add(this.btnChiTietDonHang);
            this.panel3.Controls.Add(this.btnDonHang);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(628, 107);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 330);
            this.panel3.TabIndex = 5;
            // 
            // btnTaoDonHang
            // 
            this.btnTaoDonHang.BackColor = System.Drawing.Color.Lime;
            this.btnTaoDonHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTaoDonHang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnTaoDonHang.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaoDonHang.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.newOrder2;
            this.btnTaoDonHang.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTaoDonHang.Location = new System.Drawing.Point(0, 247);
            this.btnTaoDonHang.Name = "btnTaoDonHang";
            this.btnTaoDonHang.Size = new System.Drawing.Size(300, 83);
            this.btnTaoDonHang.TabIndex = 7;
            this.btnTaoDonHang.Text = "TẠO ĐƠN HÀNG MỚI";
            this.btnTaoDonHang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTaoDonHang.UseVisualStyleBackColor = false;
            this.btnTaoDonHang.Click += new System.EventHandler(this.btnTaoDonHang_Click);
            // 
            // btnDoanhThu
            // 
            this.btnDoanhThu.BackColor = System.Drawing.SystemColors.Control;
            this.btnDoanhThu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDoanhThu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDoanhThu.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoanhThu.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.doanhThu48;
            this.btnDoanhThu.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDoanhThu.Location = new System.Drawing.Point(0, 166);
            this.btnDoanhThu.Name = "btnDoanhThu";
            this.btnDoanhThu.Size = new System.Drawing.Size(300, 83);
            this.btnDoanhThu.TabIndex = 5;
            this.btnDoanhThu.Text = "   DOANH THU";
            this.btnDoanhThu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDoanhThu.UseVisualStyleBackColor = false;
            this.btnDoanhThu.Click += new System.EventHandler(this.btnDoanhThu_Click);
            // 
            // btnChiTietDonHang
            // 
            this.btnChiTietDonHang.BackColor = System.Drawing.SystemColors.Control;
            this.btnChiTietDonHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChiTietDonHang.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnChiTietDonHang.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiTietDonHang.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.chiTietDonHang48;
            this.btnChiTietDonHang.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnChiTietDonHang.Location = new System.Drawing.Point(0, 83);
            this.btnChiTietDonHang.Name = "btnChiTietDonHang";
            this.btnChiTietDonHang.Size = new System.Drawing.Size(300, 83);
            this.btnChiTietDonHang.TabIndex = 4;
            this.btnChiTietDonHang.Text = " CHI TIẾT ĐƠN HÀNG";
            this.btnChiTietDonHang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnChiTietDonHang.UseVisualStyleBackColor = false;
            this.btnChiTietDonHang.Click += new System.EventHandler(this.btnChiTietDonHang_Click);
            // 
            // btnDonHang
            // 
            this.btnDonHang.BackColor = System.Drawing.SystemColors.Control;
            this.btnDonHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDonHang.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDonHang.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDonHang.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.donHang481;
            this.btnDonHang.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDonHang.Location = new System.Drawing.Point(0, 0);
            this.btnDonHang.Name = "btnDonHang";
            this.btnDonHang.Size = new System.Drawing.Size(300, 83);
            this.btnDonHang.TabIndex = 3;
            this.btnDonHang.Text = "   ĐƠN HÀNG";
            this.btnDonHang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDonHang.UseVisualStyleBackColor = false;
            this.btnDonHang.Click += new System.EventHandler(this.btnDonHang_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.btnMaGiamGia);
            this.panel4.Controls.Add(this.btnLichLamViec);
            this.panel4.Controls.Add(this.btnNhanVien);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 107);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(928, 330);
            this.panel4.TabIndex = 6;
            // 
            // btnMaGiamGia
            // 
            this.btnMaGiamGia.BackColor = System.Drawing.SystemColors.Control;
            this.btnMaGiamGia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaGiamGia.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMaGiamGia.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaGiamGia.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.maGiamGia48;
            this.btnMaGiamGia.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMaGiamGia.Location = new System.Drawing.Point(0, 168);
            this.btnMaGiamGia.Name = "btnMaGiamGia";
            this.btnMaGiamGia.Size = new System.Drawing.Size(928, 84);
            this.btnMaGiamGia.TabIndex = 5;
            this.btnMaGiamGia.Text = "   MÃ GIẢM GIÁ";
            this.btnMaGiamGia.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMaGiamGia.UseVisualStyleBackColor = false;
            this.btnMaGiamGia.Click += new System.EventHandler(this.btnMaGiamGia_Click);
            // 
            // btnLichLamViec
            // 
            this.btnLichLamViec.BackColor = System.Drawing.SystemColors.Control;
            this.btnLichLamViec.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLichLamViec.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnLichLamViec.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLichLamViec.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.LichLamViec48;
            this.btnLichLamViec.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLichLamViec.Location = new System.Drawing.Point(0, 84);
            this.btnLichLamViec.Name = "btnLichLamViec";
            this.btnLichLamViec.Size = new System.Drawing.Size(928, 84);
            this.btnLichLamViec.TabIndex = 4;
            this.btnLichLamViec.Text = "    LỊCH LÀM VIỆC";
            this.btnLichLamViec.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLichLamViec.UseVisualStyleBackColor = false;
            this.btnLichLamViec.Click += new System.EventHandler(this.btnLichLamViec_Click);
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.BackColor = System.Drawing.SystemColors.Control;
            this.btnNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNhanVien.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNhanVien.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhanVien.Image = global::QuanLyCuaHangThucAnNhanh.Properties.Resources.staff1;
            this.btnNhanVien.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNhanVien.Location = new System.Drawing.Point(0, 0);
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.Size = new System.Drawing.Size(928, 84);
            this.btnNhanVien.TabIndex = 3;
            this.btnNhanVien.Text = "   NHÂN VIÊN";
            this.btnNhanVien.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNhanVien.UseVisualStyleBackColor = false;
            this.btnNhanVien.Click += new System.EventHandler(this.btnNhanVien_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(928, 437);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panelMenu);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang chủ";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNguoiDangDangNhap;
        private System.Windows.Forms.TextBox txtQuyenHan;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnNguyenLieu;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDonHang;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnNhaCungCap;
        private System.Windows.Forms.Button btnSanPham;
        private System.Windows.Forms.Button btnDoanhThu;
        private System.Windows.Forms.Button btnChiTietDonHang;
        private System.Windows.Forms.Button btnMaGiamGia;
        private System.Windows.Forms.Button btnLichLamViec;
        private System.Windows.Forms.Button btnNhanVien;
        private System.Windows.Forms.Button btnTaoDonHang;
    }
}