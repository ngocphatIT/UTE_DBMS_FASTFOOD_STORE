﻿using DataAccessLayer.DALClasses;
using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLogicLayer.LogicClasses
{
    public class LichLamViecLogic
    {
        LichLamViecDAL dal = new LichLamViecDAL();
        public List<LichLamViec> LichLamViecList()
        {
            var list = dal.getLichLamViecList();
            return list;
        }
    }
}
