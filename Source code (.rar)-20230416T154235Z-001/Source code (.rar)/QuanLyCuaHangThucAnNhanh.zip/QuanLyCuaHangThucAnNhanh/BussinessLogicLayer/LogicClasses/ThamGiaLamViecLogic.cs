﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLogicLayer.LogicClasses
{
    public class ThamGiaLamViecLogic
    {
        //    DAL dal = new DAL();
        //    public List<NguyenLieu> List()
        //    {
        //        var list = dal.getList();
        //        return list;
        //    }
        //}
    }
}
