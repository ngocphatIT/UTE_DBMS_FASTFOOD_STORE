﻿using DataAccessLayer.DALClasses;
using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLogicLayer.LogicClasses
{
    public class SanPhamLogic
    {
        SanPhamDAL dal = new SanPhamDAL();

        public List<SanPham> SanPhamList()
        {
            var list = dal.getSanPhamList();
            return list;
        }

        public SanPham findByName(string name)
        {
            return dal.findByName(name);
        }

        public SanPham findById(string id)
        {
            return dal.findById(id);
        }

    }
}
